﻿using System;

namespace Klasser
{
    class Program
    {
        /// <summary>
        /// Se instruktionenr i Uppgift.txt
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {

            Console.WriteLine("Hello World!");
        }
    }

    public class Bil
    {
        public string Registreringsnummer { get; set; }

    }
}