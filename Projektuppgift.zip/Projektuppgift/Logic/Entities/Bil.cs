﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logic.Entities
{
    class Bil
    {
        public bool Dragkok { get; set; }
    }
}
