﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logic.Entities
{
    class Verkstad
    {
        List<Fordon> fordoniverkstad = new List<Fordon>();

        public void Registrerafordon()
        {
            Fordon bil = new Fordon();
            Console.Write("Modell på fordon?: ");
            bil.Modellnamn = Console.ReadLine();
            Console.Write("Registreringsnummer?: ");
            bil.Registreringsnummer = Console.ReadLine();
            Console.WriteLine("Mil bilen åkt?: ");
            bil.Milmätare = Convert.ToDecimal(Console.ReadLine());
            Console.WriteLine("Bilen registrerades?: ");
            bil.Registreringsdatum = Console.ReadLine();
            Console.WriteLine("Typ av drivmedel? [1]Bensin [2]El [3]Diesel [4]Etanol: ");

            switch (case)
            {
                    
                
                    break;
            }
        }
    }
}
