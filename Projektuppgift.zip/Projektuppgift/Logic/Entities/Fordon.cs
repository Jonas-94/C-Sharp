﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logic.Entities
{
     class Fordon
    {
        public string Modellnamn { get; set; }
        public string Registreringsnummer { get; set; }
        public decimal Milmätare { get; set; }
        public string Registreringsdatum { get; set; }
        public bool Bensin { get; set; }
        public bool El { get; set; }
        public bool Diesel { get; set; }
        public bool Etanol { get; set; }

        
    }
}
